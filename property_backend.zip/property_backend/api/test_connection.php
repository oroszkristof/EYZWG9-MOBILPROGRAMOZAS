<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

try {
    $connection = getDatabaseConnection();

    echo 'Sikeres adatbázis-kapcsolat!';
} catch (PDOException $exception) {
    http_response_code(500);

    echo 'Nem sikerült csatlakozni az adatbázishoz.';
}