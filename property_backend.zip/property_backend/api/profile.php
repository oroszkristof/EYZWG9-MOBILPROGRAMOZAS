
<?php

header("Content-Type: application/json; charset=utf-8");

require_once "../config/database.php";

$method = $_SERVER["REQUEST_METHOD"];

if (!in_array($method, ["GET", "PUT", "DELETE"])) {
    http_response_code(405);
    echo json_encode(["message" => "Nem támogatott kérés."]);
    exit;
}

$data = [];

if ($method !== "GET") {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!is_array($data)) {
        http_response_code(400);
        echo json_encode(["message" => "Hibás kérés."]);
        exit;
    }
}

$userId = $method === "GET"
    ? filter_input(INPUT_GET, "userId", FILTER_VALIDATE_INT)
    : filter_var($data["userId"] ?? null, FILTER_VALIDATE_INT);

if (!$userId || $userId <= 0) {
    http_response_code(400);
    echo json_encode(["message" => "Érvénytelen felhasználóazonosító."]);
    exit;
}

try {
    $connection = getDatabaseConnection();

    if ($method === "GET") {
        $statement = $connection->prepare(
            "SELECT id, name, email, phone FROM users WHERE id = ?"
        );

        $statement->bind_param("i", $userId);
        $statement->execute();

        $user = $statement->get_result()->fetch_assoc();

        if (!$user) {
            http_response_code(404);
            echo json_encode(["message" => "A felhasználó nem található."]);
        } else {
            echo json_encode([
                "message" => "Profiladatok sikeresen lekérve.",
                "user" => $user
            ], JSON_UNESCAPED_UNICODE);
        }

        $statement->close();
    }

    if ($method === "PUT") {
        $name = trim($data["name"] ?? "");
        $email = trim($data["email"] ?? "");
        $phone = trim($data["phone"] ?? "");
        $password = $data["password"] ?? "";

        if (
            $name === "" ||
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            strlen($phone) > 30
        ) {
            http_response_code(400);
            echo json_encode(["message" => "Hibás profiladatok."]);
            exit;
        }

        if ($password !== "" && strlen($password) < 8) {
            http_response_code(400);
            echo json_encode([
                "message" => "A jelszónak legalább 8 karakterből kell állnia."
            ]);
            exit;
        }

        $statement = $connection->prepare(
            "SELECT id FROM users WHERE id = ?"
        );

        $statement->bind_param("i", $userId);
        $statement->execute();

        if (!$statement->get_result()->fetch_assoc()) {
            http_response_code(404);
            echo json_encode(["message" => "A felhasználó nem található."]);
            exit;
        }

        $statement->close();

        $statement = $connection->prepare(
            "SELECT id FROM users WHERE email = ? AND id != ?"
        );

        $statement->bind_param("si", $email, $userId);
        $statement->execute();

        if ($statement->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(["message" => "Ez az e-mail-cím már foglalt."]);
            exit;
        }

        $statement->close();

        $phone = $phone === "" ? null : $phone;

        if ($password === "") {
            $statement = $connection->prepare(
                "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?"
            );

            $statement->bind_param(
                "sssi",
                $name,
                $email,
                $phone,
                $userId
            );
        } else {
            $statement = $connection->prepare(
                "UPDATE users SET name = ?, email = ?, phone = ?, password = ? WHERE id = ?"
            );

            $statement->bind_param(
                "ssssi",
                $name,
                $email,
                $phone,
                $password,
                $userId
            );
        }

        $statement->execute();
        $statement->close();

        echo json_encode([
            "message" => "A profiladatok sikeresen módosítva.",
            "user" => [
                "id" => $userId,
                "name" => $name,
                "email" => $email,
                "phone" => $phone
            ]
        ], JSON_UNESCAPED_UNICODE);
    }

    if ($method === "DELETE") {
        $statement = $connection->prepare(
            "DELETE FROM users WHERE id = ?"
        );

        $statement->bind_param("i", $userId);
        $statement->execute();

        if ($statement->affected_rows === 0) {
            http_response_code(404);
            echo json_encode(["message" => "A felhasználó nem található."]);
        } else {
            echo json_encode([
                "message" => "A felhasználói fiók sikeresen törölve."
            ], JSON_UNESCAPED_UNICODE);
        }

        $statement->close();
    }

    $connection->close();

} catch (mysqli_sql_exception $exception) {
    http_response_code(500);
    echo json_encode(["message" => "Adatbázishiba történt."]);
}
