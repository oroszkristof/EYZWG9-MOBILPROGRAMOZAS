
<?php

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . "/../config/database.php";

function sendResponse(int $status, array $data): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function readJsonInput(): array
{
    $raw = file_get_contents("php://input");
    $input = json_decode($raw === false ? "" : $raw, true);

    if (!is_array($input)) {
        sendResponse(400, [
            "success" => false,
            "message" => "Érvénytelen JSON-adatok."
        ]);
    }

    return $input;
}

function validId($value): int
{
    $id = filter_var($value, FILTER_VALIDATE_INT);

    return $id !== false && $id > 0 ? $id : 0;
}

function validAmount($value): ?float
{
    if (!is_numeric($value)) {
        return null;
    }

    $amount = (float)$value;

    if (
        !is_finite($amount) ||
        $amount <= 0 ||
        $amount > 9999999999.99
    ) {
        return null;
    }

    return round($amount, 2);
}

function validBillType($value): bool
{
    return is_string($value) &&
        in_array(
            $value,
            ["gaz", "villany", "viz", "berleti_dij"],
            true
        );
}

function formatBill(array $bill): array
{
    return [
        "id" => (int)$bill["id"],
        "propertyId" => (int)$bill["property_id"],
        "ownerId" => (int)$bill["owner_id"],
        "tenantId" => (int)$bill["tenant_id"],
        "billType" => $bill["bill_type"],
        "amount" => (float)$bill["amount"],
        "status" => $bill["status"],
        "createdAt" => $bill["created_at"],
        "paymentReportedAt" => $bill["payment_reported_at"],
        "approvedAt" => $bill["approved_at"],
        "propertyName" => $bill["property_name"] ?? null,
        "tenantName" => $bill["tenant_name"] ?? null
    ];
}

function getUserRole(mysqli $db, int $userId): ?string
{
    $stmt = $db->prepare(
        "SELECT role FROM users WHERE id = ?"
    );

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $user["role"] ?? null;
}

function ownerHasProperty(
    mysqli $db,
    int $ownerId,
    int $propertyId,
    int $tenantId
): bool {
    $stmt = $db->prepare(
        "SELECT id
         FROM properties
         WHERE id = ?
           AND owner_id = ?
           AND tenant_id = ?"
    );

    $stmt->bind_param(
        "iii",
        $propertyId,
        $ownerId,
        $tenantId
    );

    $stmt->execute();

    $exists = $stmt->get_result()->fetch_assoc() !== null;
    $stmt->close();

    return $exists;
}

try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $db = getDatabaseConnection();

    $method = $_SERVER["REQUEST_METHOD"] ?? "";
    $action = $_GET["action"] ?? "";

    if ($method === "GET" && $action === "list") {
        $userId = validId($_GET["user_id"] ?? null);

        if ($userId === 0) {
            sendResponse(400, [
                "success" => false,
                "message" => "Hiányzó felhasználóazonosító."
            ]);
        }

        $role = getUserRole($db, $userId);

        if ($role === null) {
            sendResponse(404, [
                "success" => false,
                "message" => "Felhasználó nem található."
            ]);
        }

        if ($role === "tulajdonos") {
            $sql = "
                SELECT
                    b.*,
                    p.name AS property_name,
                    u.name AS tenant_name
                FROM utility_bills b
                JOIN properties p ON p.id = b.property_id
                JOIN users u ON u.id = b.tenant_id
                WHERE b.owner_id = ?
                ORDER BY b.created_at DESC, b.id DESC
            ";
        } elseif ($role === "bérlő") {
            $sql = "
                SELECT
                    b.*,
                    p.name AS property_name,
                    u.name AS tenant_name
                FROM utility_bills b
                JOIN properties p ON p.id = b.property_id
                JOIN users u ON u.id = b.tenant_id
                WHERE b.tenant_id = ?
                ORDER BY b.created_at DESC, b.id DESC
            ";
        } else {
            sendResponse(403, [
                "success" => false,
                "message" => "Ismeretlen felhasználói szerepkör."
            ]);
        }

        $stmt = $db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        $result = $stmt->get_result();
        $bills = [];

        while ($bill = $result->fetch_assoc()) {
            $bills[] = formatBill($bill);
        }

        $stmt->close();

        sendResponse(200, [
            "success" => true,
            "bills" => $bills
        ]);
    }

    if ($method === "POST" && $action === "create") {
        $input = readJsonInput();

        $ownerId = validId($input["ownerId"] ?? null);
        $propertyId = validId($input["propertyId"] ?? null);
        $tenantId = validId($input["tenantId"] ?? null);
        $billType = $input["billType"] ?? null;
        $amount = validAmount($input["amount"] ?? null);

        if (
            $ownerId === 0 ||
            $propertyId === 0 ||
            $tenantId === 0 ||
            !validBillType($billType) ||
            $amount === null
        ) {
            sendResponse(400, [
                "success" => false,
                "message" => "Érvénytelen számlaadatok."
            ]);
        }

        if (getUserRole($db, $ownerId) !== "tulajdonos") {
            sendResponse(403, [
                "success" => false,
                "message" => "Csak tulajdonos hozhat létre számlát."
            ]);
        }

        if (
            !ownerHasProperty(
                $db,
                $ownerId,
                $propertyId,
                $tenantId
            )
        ) {
            sendResponse(403, [
                "success" => false,
                "message" => "A bérlő nincs ehhez az ingatlanhoz rendelve."
            ]);
        }

        $stmt = $db->prepare(
            "INSERT INTO utility_bills
             (property_id, owner_id, tenant_id, bill_type, amount)
             VALUES (?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "iiisd",
            $propertyId,
            $ownerId,
            $tenantId,
            $billType,
            $amount
        );

        $stmt->execute();

        $billId = $db->insert_id;
        $stmt->close();

        sendResponse(201, [
            "success" => true,
            "message" => "A számla sikeresen létrejött.",
            "billId" => $billId
        ]);
    }

    if ($method === "POST" && $action === "update") {
        $input = readJsonInput();

        $billId = validId($input["billId"] ?? null);
        $ownerId = validId($input["ownerId"] ?? null);
        $billType = $input["billType"] ?? null;
        $amount = validAmount($input["amount"] ?? null);

        if (
            $billId === 0 ||
            $ownerId === 0 ||
            !validBillType($billType) ||
            $amount === null
        ) {
            sendResponse(400, [
                "success" => false,
                "message" => "Érvénytelen módosítási adatok."
            ]);
        }

        if (getUserRole($db, $ownerId) !== "tulajdonos") {
            sendResponse(403, [
                "success" => false,
                "message" => "Csak tulajdonos módosíthat számlát."
            ]);
        }

        $stmt = $db->prepare(
            "UPDATE utility_bills
             SET bill_type = ?,
                 amount = ?
             WHERE id = ?
               AND owner_id = ?
               AND status = 'fizetesre_var'"
        );

        $stmt->bind_param(
            "sdii",
            $billType,
            $amount,
            $billId,
            $ownerId
        );

        $stmt->execute();
        $stmt->close();

        $check = $db->prepare(
            "SELECT id
             FROM utility_bills
             WHERE id = ?
               AND owner_id = ?
               AND bill_type = ?
               AND amount = ?
               AND status = 'fizetesre_var'"
        );

        $check->bind_param(
            "iisd",
            $billId,
            $ownerId,
            $billType,
            $amount
        );

        $check->execute();

        $updated = $check->get_result()->fetch_assoc() !== null;
        $check->close();

        if (!$updated) {
            sendResponse(409, [
                "success" => false,
                "message" => "A számla nem módosítható. Csak fizetésre váró számla szerkeszthető."
            ]);
        }

        sendResponse(200, [
            "success" => true,
            "message" => "A számla sikeresen módosítva."
        ]);
    }

    if ($method === "POST" && $action === "delete") {
        $input = readJsonInput();

        $billId = validId($input["billId"] ?? null);
        $ownerId = validId($input["ownerId"] ?? null);

        if ($billId === 0 || $ownerId === 0) {
            sendResponse(400, [
                "success" => false,
                "message" => "Hiányzó adatok."
            ]);
        }

        if (getUserRole($db, $ownerId) !== "tulajdonos") {
            sendResponse(403, [
                "success" => false,
                "message" => "Csak tulajdonos törölhet számlát."
            ]);
        }

        $stmt = $db->prepare(
            "DELETE FROM utility_bills
             WHERE id = ?
               AND owner_id = ?
               AND status = 'fizetesre_var'"
        );

        $stmt->bind_param(
            "ii",
            $billId,
            $ownerId
        );

        $stmt->execute();

        $deleted = $stmt->affected_rows;
        $stmt->close();

        if ($deleted !== 1) {
            sendResponse(409, [
                "success" => false,
                "message" => "A számla nem törölhető. Csak fizetésre váró számla törölhető."
            ]);
        }

        sendResponse(200, [
            "success" => true,
            "message" => "A számla sikeresen törölve."
        ]);
    }

    if ($method === "POST" && $action === "report_payment") {
        $input = readJsonInput();

        $billId = validId($input["billId"] ?? null);
        $tenantId = validId($input["tenantId"] ?? null);

        if ($billId === 0 || $tenantId === 0) {
            sendResponse(400, [
                "success" => false,
                "message" => "Hiányzó adatok."
            ]);
        }

        if (getUserRole($db, $tenantId) !== "bérlő") {
            sendResponse(403, [
                "success" => false,
                "message" => "Csak bérlő jelenthet be befizetést."
            ]);
        }

        $stmt = $db->prepare(
            "UPDATE utility_bills
             SET status = 'elfogadasra_var',
                 payment_reported_at = NOW()
             WHERE id = ?
               AND tenant_id = ?
               AND status = 'fizetesre_var'"
        );

        $stmt->bind_param(
            "ii",
            $billId,
            $tenantId
        );

        $stmt->execute();

        $updated = $stmt->affected_rows;
        $stmt->close();

        if ($updated !== 1) {
            sendResponse(409, [
                "success" => false,
                "message" => "A befizetés nem jelenthető be."
            ]);
        }

        sendResponse(200, [
            "success" => true,
            "message" => "A befizetés bejelentve. Tulajdonosi jóváhagyásra vár."
        ]);
    }

    if ($method === "POST" && $action === "approve_payment") {
        $input = readJsonInput();

        $billId = validId($input["billId"] ?? null);
        $ownerId = validId($input["ownerId"] ?? null);

        if ($billId === 0 || $ownerId === 0) {
            sendResponse(400, [
                "success" => false,
                "message" => "Hiányzó adatok."
            ]);
        }

        if (getUserRole($db, $ownerId) !== "tulajdonos") {
            sendResponse(403, [
                "success" => false,
                "message" => "Csak tulajdonos hagyhat jóvá befizetést."
            ]);
        }

        $stmt = $db->prepare(
            "UPDATE utility_bills
             SET status = 'befizetve',
                 approved_at = NOW()
             WHERE id = ?
               AND owner_id = ?
               AND status = 'elfogadasra_var'"
        );

        $stmt->bind_param(
            "ii",
            $billId,
            $ownerId
        );

        $stmt->execute();

        $updated = $stmt->affected_rows;
        $stmt->close();

        if ($updated !== 1) {
            sendResponse(409, [
                "success" => false,
                "message" => "A befizetés nem hagyható jóvá."
            ]);
        }

        sendResponse(200, [
            "success" => true,
            "message" => "A befizetés sikeresen jóváhagyva."
        ]);
    }

    sendResponse(404, [
        "success" => false,
        "message" => "Ismeretlen API-művelet."
    ]);

} catch (mysqli_sql_exception $exception) {
    sendResponse(500, [
        "success" => false,
        "message" => "Adatbázishiba történt."
    ]);
} catch (Throwable $exception) {
    sendResponse(500, [
        "success" => false,
        "message" => "Váratlan szerverhiba történt."
    ]);
}
