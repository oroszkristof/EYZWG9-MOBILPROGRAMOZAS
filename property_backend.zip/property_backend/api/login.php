
<?php

header("Content-Type: application/json; charset=utf-8");

require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["message" => "Nem támogatott kérés."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data["email"] ?? "");
$password = $data["password"] ?? "";

if ($email == "" || $password == "") {
    http_response_code(400);
    echo json_encode(["message" => "Az e-mail-cím és a jelszó megadása kötelező."]);
    exit;
}

try {
    $connection = getDatabaseConnection();

    $statement = $connection->prepare(
        "SELECT id, name, email, phone, password FROM users WHERE email = ?"
    );

    $statement->bind_param("s", $email);
    $statement->execute();

    $result = $statement->get_result();
    $user = $result->fetch_assoc();

    if (!$user || $password != $user["password"]) {
        http_response_code(401);
        echo json_encode(["message" => "Hibás e-mail-cím vagy jelszó."]);
        exit;
    }

    echo json_encode([
        "message" => "Sikeres bejelentkezés!",
        "user" => [
            "id" => $user["id"],
            "name" => $user["name"],
            "email" => $user["email"],
            "phone" => $user["phone"]
        ]
    ], JSON_UNESCAPED_UNICODE);

    $statement->close();
    $connection->close();

} catch (mysqli_sql_exception $exception) {
    http_response_code(500);
    echo json_encode(["message" => "Adatbázishiba történt."]);
}
