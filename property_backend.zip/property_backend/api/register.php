
<?php

header("Content-Type: application/json; charset=utf-8");

require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["message" => "Nem támogatott kérés."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$name = trim($data["name"] ?? "");
$email = trim($data["email"] ?? "");
$phone = trim($data["phone"] ?? "");
$password = $data["password"] ?? "";

if ($name == "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
    http_response_code(400);
    echo json_encode(["message" => "Hibás regisztrációs adatok."]);
    exit;
}

if (strlen($phone) > 30) {
    http_response_code(400);
    echo json_encode(["message" => "A telefonszám legfeljebb 30 karakter lehet."]);
    exit;
}

$phone = $phone === "" ? null : $phone;

try {
    $connection = getDatabaseConnection();

    $statement = $connection->prepare(
        "SELECT id FROM users WHERE email = ?"
    );

    $statement->bind_param("s", $email);
    $statement->execute();

    $result = $statement->get_result();

    if ($result->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["message" => "Ez az e-mail-cím már foglalt."]);
        exit;
    }

    $statement->close();

    $statement = $connection->prepare(
        "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)"
    );

    $statement->bind_param("ssss", $name, $email, $phone, $password);
    $statement->execute();

    http_response_code(201);

    echo json_encode([
        "message" => "Sikeres regisztráció!",
        "userId" => $connection->insert_id
    ], JSON_UNESCAPED_UNICODE);

    $statement->close();
    $connection->close();

} catch (mysqli_sql_exception $exception) {
    http_response_code(500);
    echo json_encode(["message" => "Adatbázishiba történt."]);
}
