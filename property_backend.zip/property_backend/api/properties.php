
<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

$connection = getDatabaseConnection();

$method = $_SERVER["REQUEST_METHOD"];

$data = json_decode(file_get_contents("php://input"), true) ?? [];

function sendResponse($status, $result) {
    http_response_code($status);
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === "POST") {

    $ownerId = $data["ownerId"] ?? null;
    $name = trim($data["name"] ?? "");
    $address = trim($data["address"] ?? "");
    $monthlyRent = $data["monthlyRent"] ?? null;
    $paymentDueDay = $data["paymentDueDay"] ?? null;

    if (
        !filter_var($ownerId, FILTER_VALIDATE_INT) ||
        $ownerId < 1 ||
        $name === "" ||
        $address === "" ||
        $monthlyRent === null ||
        $paymentDueDay === null
    ) {
        sendResponse(400, [
            "message" => "Minden mező kitöltése kötelező."
        ]);
    }

    if (
        mb_strlen($name) > 100 ||
        mb_strlen($address) > 255 ||
        !is_numeric($monthlyRent) ||
        $monthlyRent < 0 ||
        $monthlyRent > 99999999.99 ||
        !filter_var($paymentDueDay, FILTER_VALIDATE_INT) ||
        $paymentDueDay < 1 ||
        $paymentDueDay > 28
    ) {
        sendResponse(400, [
            "message" => "Érvénytelen ingatlanadatok."
        ]);
    }

    $statement = $connection->prepare(
        "INSERT INTO properties
         (owner_id, name, address, monthly_rent, payment_due_day)
         VALUES (?, ?, ?, ?, ?)"
    );

    $statement->bind_param(
        "issdi",
        $ownerId,
        $name,
        $address,
        $monthlyRent,
        $paymentDueDay
    );

    if ($statement->execute()) {
        sendResponse(201, [
            "message" => "Az ingatlan sikeresen hozzáadva.",
            "propertyId" => $connection->insert_id
        ]);
    }

    sendResponse(500, [
        "message" => "Nem sikerült menteni az ingatlant."
    ]);
}

if ($method === "GET") {

    $ownerId = filter_input(
        INPUT_GET,
        "ownerId",
        FILTER_VALIDATE_INT
    );

    $propertyId = filter_input(
        INPUT_GET,
        "propertyId",
        FILTER_VALIDATE_INT
    );

    if (!$ownerId || $ownerId < 1) {
        sendResponse(400, [
            "message" => "Érvénytelen felhasználói azonosító."
        ]);
    }

    if (isset($_GET["propertyId"])) {

        if (!$propertyId || $propertyId < 1) {
            sendResponse(400, [
                "message" => "Érvénytelen ingatlanazonosító."
            ]);
        }

        $statement = $connection->prepare(
            "SELECT id, owner_id, name, address,
                    monthly_rent, payment_due_day
             FROM properties
             WHERE id = ? AND owner_id = ?"
        );

        $statement->bind_param(
            "ii",
            $propertyId,
            $ownerId
        );

    } else {

        $statement = $connection->prepare(
            "SELECT id, owner_id, name, address,
                    monthly_rent, payment_due_day
             FROM properties
             WHERE owner_id = ?
             ORDER BY id DESC"
        );

        $statement->bind_param("i", $ownerId);
    }

    $statement->execute();

    $result = $statement->get_result();

    $properties = [];

    while ($row = $result->fetch_assoc()) {
        $properties[] = [
            "id" => (int) $row["id"],
            "ownerId" => (int) $row["owner_id"],
            "name" => $row["name"],
            "address" => $row["address"],
            "monthlyRent" => (float) $row["monthly_rent"],
            "paymentDueDay" => (int) $row["payment_due_day"]
        ];
    }

    if (isset($_GET["propertyId"])) {

        if (count($properties) === 0) {
            sendResponse(404, [
                "message" => "Az ingatlan nem található."
            ]);
        }

        sendResponse(200, [
            "property" => $properties[0]
        ]);
    }

    sendResponse(200, [
        "properties" => $properties
    ]);
}

if ($method === "PUT") {

    $propertyId = $data["propertyId"] ?? null;
    $ownerId = $data["ownerId"] ?? null;
    $name = trim($data["name"] ?? "");
    $address = trim($data["address"] ?? "");
    $monthlyRent = $data["monthlyRent"] ?? null;
    $paymentDueDay = $data["paymentDueDay"] ?? null;

    if (
        !filter_var($propertyId, FILTER_VALIDATE_INT) ||
        $propertyId < 1 ||
        !filter_var($ownerId, FILTER_VALIDATE_INT) ||
        $ownerId < 1 ||
        $name === "" ||
        $address === "" ||
        $monthlyRent === null ||
        $paymentDueDay === null
    ) {
        sendResponse(400, [
            "message" => "Minden mező kitöltése kötelező."
        ]);
    }

    if (
        mb_strlen($name) > 100 ||
        mb_strlen($address) > 255 ||
        !is_numeric($monthlyRent) ||
        $monthlyRent < 0 ||
        $monthlyRent > 99999999.99 ||
        !filter_var($paymentDueDay, FILTER_VALIDATE_INT) ||
        $paymentDueDay < 1 ||
        $paymentDueDay > 28
    ) {
        sendResponse(400, [
            "message" => "Érvénytelen ingatlanadatok."
        ]);
    }

    $statement = $connection->prepare(
        "UPDATE properties
         SET name = ?,
             address = ?,
             monthly_rent = ?,
             payment_due_day = ?
         WHERE id = ? AND owner_id = ?"
    );

    $statement->bind_param(
        "ssdiii",
        $name,
        $address,
        $monthlyRent,
        $paymentDueDay,
        $propertyId,
        $ownerId
    );

    if ($statement->execute()) {

        if ($statement->affected_rows === 0) {
            sendResponse(200, [
                "message" => "Nem történt adatváltozás, vagy az ingatlan nem található."
            ]);
        }

        sendResponse(200, [
            "message" => "Az ingatlan sikeresen módosítva."
        ]);
    }

    sendResponse(500, [
        "message" => "Nem sikerült módosítani az ingatlant."
    ]);
}

if ($method === "DELETE") {

    $propertyId = $data["propertyId"] ?? null;
    $ownerId = $data["ownerId"] ?? null;

    if (
        !filter_var($propertyId, FILTER_VALIDATE_INT) ||
        $propertyId < 1 ||
        !filter_var($ownerId, FILTER_VALIDATE_INT) ||
        $ownerId < 1
    ) {
        sendResponse(400, [
            "message" => "Érvénytelen azonosító."
        ]);
    }

    $statement = $connection->prepare(
        "DELETE FROM properties
         WHERE id = ? AND owner_id = ?"
    );

    $statement->bind_param(
        "ii",
        $propertyId,
        $ownerId
    );

    if ($statement->execute()) {

        if ($statement->affected_rows === 0) {
            sendResponse(404, [
                "message" => "Az ingatlan nem található."
            ]);
        }

        sendResponse(200, [
            "message" => "Az ingatlan sikeresen törölve."
        ]);
    }

    sendResponse(500, [
        "message" => "Nem sikerült törölni az ingatlant."
    ]);
}

header("Allow: GET, POST, PUT, DELETE");

sendResponse(405, [
    "message" => "Nem támogatott kérési metódus."
]);

?>
