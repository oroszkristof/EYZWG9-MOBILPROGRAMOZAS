
<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

$connection = getDatabaseConnection();

$method = $_SERVER["REQUEST_METHOD"];

$data = json_decode(file_get_contents("php://input"), true) ?? [];

function sendResponse($status, $result) {
    http_response_code($status);
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit;
}

function validId($value) {
    return filter_var($value, FILTER_VALIDATE_INT) !== false
        && (int) $value > 0;
}

function getUserRole($connection, $userId) {
    $statement = $connection->prepare(
        "SELECT role FROM users WHERE id = ?"
    );

    $statement->bind_param("i", $userId);
    $statement->execute();

    $result = $statement->get_result();
    $user = $result->fetch_assoc();

    return $user["role"] ?? null;
}

function getPropertySelect() {
    return "
        SELECT
            p.id,
            p.owner_id,
            p.name,
            p.address,
            p.monthly_rent,
            p.payment_due_day,
            p.tenant_id,
            owner.name AS owner_name,
            owner.email AS owner_email,
            owner.phone AS owner_phone,
            tenant.name AS tenant_name,
            tenant.email AS tenant_email,
            tenant.phone AS tenant_phone
        FROM properties p
        INNER JOIN users owner
            ON owner.id = p.owner_id
        LEFT JOIN users tenant
            ON tenant.id = p.tenant_id
    ";
}

function formatProperty($row) {
    return [
        "id" => (int) $row["id"],
        "ownerId" => (int) $row["owner_id"],
        "name" => $row["name"],
        "address" => $row["address"],
        "monthlyRent" => (float) $row["monthly_rent"],
        "paymentDueDay" => (int) $row["payment_due_day"],
        "tenantId" => $row["tenant_id"] === null
            ? null
            : (int) $row["tenant_id"],
        "ownerName" => $row["owner_name"],
        "ownerEmail" => $row["owner_email"],
        "ownerPhone" => $row["owner_phone"],
        "tenantName" => $row["tenant_name"],
        "tenantEmail" => $row["tenant_email"],
        "tenantPhone" => $row["tenant_phone"]
    ];
}

if ($method === "POST") {

    $ownerId = $data["ownerId"] ?? null;
    $name = trim($data["name"] ?? "");
    $address = trim($data["address"] ?? "");
    $monthlyRent = $data["monthlyRent"] ?? null;
    $paymentDueDay = $data["paymentDueDay"] ?? null;

    if (
        !validId($ownerId) ||
        $name === "" ||
        $address === "" ||
        $monthlyRent === null ||
        $paymentDueDay === null
    ) {
        sendResponse(400, [
            "message" => "Minden mező kitöltése kötelező."
        ]);
    }

    if (
        mb_strlen($name) > 100 ||
        mb_strlen($address) > 255 ||
        !is_numeric($monthlyRent) ||
        $monthlyRent < 0 ||
        $monthlyRent > 99999999.99 ||
        !filter_var($paymentDueDay, FILTER_VALIDATE_INT) ||
        $paymentDueDay < 1 ||
        $paymentDueDay > 28
    ) {
        sendResponse(400, [
            "message" => "Érvénytelen ingatlanadatok."
        ]);
    }

    if (getUserRole($connection, $ownerId) !== "tulajdonos") {
        sendResponse(403, [
            "message" => "Csak tulajdonos adhat hozzá ingatlant."
        ]);
    }

    $statement = $connection->prepare(
        "INSERT INTO properties
         (owner_id, name, address, monthly_rent, payment_due_day)
         VALUES (?, ?, ?, ?, ?)"
    );

    $statement->bind_param(
        "issdi",
        $ownerId,
        $name,
        $address,
        $monthlyRent,
        $paymentDueDay
    );

    if ($statement->execute()) {
        sendResponse(201, [
            "message" => "Az ingatlan sikeresen hozzáadva.",
            "propertyId" => $connection->insert_id
        ]);
    }

    sendResponse(500, [
        "message" => "Nem sikerült menteni az ingatlant."
    ]);
}

if ($method === "GET") {

    $userId = filter_input(
        INPUT_GET,
        "ownerId",
        FILTER_VALIDATE_INT
    );

    $propertyId = filter_input(
        INPUT_GET,
        "propertyId",
        FILTER_VALIDATE_INT
    );

    if (!$userId || $userId < 1) {
        sendResponse(400, [
            "message" => "Érvénytelen felhasználói azonosító."
        ]);
    }

    $role = getUserRole($connection, $userId);

    if ($role === null) {
        sendResponse(404, [
            "message" => "A felhasználó nem található."
        ]);
    }

    $select = getPropertySelect();

    if (isset($_GET["propertyId"])) {

        if (!$propertyId || $propertyId < 1) {
            sendResponse(400, [
                "message" => "Érvénytelen ingatlanazonosító."
            ]);
        }

        if ($role === "tulajdonos") {
            $statement = $connection->prepare(
                $select . "
                WHERE p.id = ? AND p.owner_id = ?"
            );
        } else {
            $statement = $connection->prepare(
                $select . "
                WHERE p.id = ? AND p.tenant_id = ?"
            );
        }

        $statement->bind_param(
            "ii",
            $propertyId,
            $userId
        );

    } else {

        if ($role === "tulajdonos") {
            $statement = $connection->prepare(
                $select . "
                WHERE p.owner_id = ?
                ORDER BY p.id DESC"
            );
        } else {
            $statement = $connection->prepare(
                $select . "
                WHERE p.tenant_id = ?
                ORDER BY p.id DESC"
            );
        }

        $statement->bind_param("i", $userId);
    }

    $statement->execute();

    $result = $statement->get_result();

    $properties = [];

    while ($row = $result->fetch_assoc()) {
        $properties[] = formatProperty($row);
    }

    if (isset($_GET["propertyId"])) {

        if (count($properties) === 0) {
            sendResponse(404, [
                "message" => "Az ingatlan nem található."
            ]);
        }

        sendResponse(200, [
            "property" => $properties[0]
        ]);
    }

    sendResponse(200, [
        "properties" => $properties
    ]);
}

if ($method === "PUT") {

    $propertyId = $data["propertyId"] ?? null;
    $ownerId = $data["ownerId"] ?? null;

    if (!validId($propertyId) || !validId($ownerId)) {
        sendResponse(400, [
            "message" => "Érvénytelen azonosító."
        ]);
    }

    if (getUserRole($connection, $ownerId) !== "tulajdonos") {
        sendResponse(403, [
            "message" => "Csak tulajdonos módosíthat ingatlant."
        ]);
    }

    $action = $data["action"] ?? "";

    if ($action === "assignTenant") {

        $tenantId = $data["tenantId"] ?? null;

        if ($tenantId !== null && !validId($tenantId)) {
            sendResponse(400, [
                "message" => "Érvénytelen bérlőazonosító."
            ]);
        }

        if ($tenantId !== null) {
            if (getUserRole($connection, $tenantId) !== "bérlő") {
                sendResponse(400, [
                    "message" => "A kiválasztott felhasználó nem bérlő."
                ]);
            }
        }

        $statement = $connection->prepare(
            "SELECT id
             FROM properties
             WHERE id = ? AND owner_id = ?"
        );

        $statement->bind_param(
            "ii",
            $propertyId,
            $ownerId
        );

        $statement->execute();

        if ($statement->get_result()->num_rows === 0) {
            sendResponse(404, [
                "message" => "Az ingatlan nem található."
            ]);
        }

        $statement = $connection->prepare(
            "UPDATE properties
             SET tenant_id = ?
             WHERE id = ? AND owner_id = ?"
        );

        $statement->bind_param(
            "iii",
            $tenantId,
            $propertyId,
            $ownerId
        );

        if ($statement->execute()) {
            sendResponse(200, [
                "message" => $tenantId === null
                    ? "A bérlő hozzárendelése megszüntetve."
                    : "A bérlő sikeresen hozzárendelve."
            ]);
        }

        sendResponse(500, [
            "message" => "Nem sikerült módosítani a hozzárendelést."
        ]);
    }

    $name = trim($data["name"] ?? "");
    $address = trim($data["address"] ?? "");
    $monthlyRent = $data["monthlyRent"] ?? null;
    $paymentDueDay = $data["paymentDueDay"] ?? null;

    if (
        $name === "" ||
        $address === "" ||
        $monthlyRent === null ||
        $paymentDueDay === null
    ) {
        sendResponse(400, [
            "message" => "Minden mező kitöltése kötelező."
        ]);
    }

    if (
        mb_strlen($name) > 100 ||
        mb_strlen($address) > 255 ||
        !is_numeric($monthlyRent) ||
        $monthlyRent < 0 ||
        $monthlyRent > 99999999.99 ||
        !filter_var($paymentDueDay, FILTER_VALIDATE_INT) ||
        $paymentDueDay < 1 ||
        $paymentDueDay > 28
    ) {
        sendResponse(400, [
            "message" => "Érvénytelen ingatlanadatok."
        ]);
    }

    $statement = $connection->prepare(
        "UPDATE properties
         SET name = ?,
             address = ?,
             monthly_rent = ?,
             payment_due_day = ?
         WHERE id = ? AND owner_id = ?"
    );

    $statement->bind_param(
        "ssdiii",
        $name,
        $address,
        $monthlyRent,
        $paymentDueDay,
        $propertyId,
        $ownerId
    );

    if ($statement->execute()) {

        if ($statement->affected_rows === 0) {
            sendResponse(200, [
                "message" => "Nem történt adatváltozás, vagy az ingatlan nem található."
            ]);
        }

        sendResponse(200, [
            "message" => "Az ingatlan sikeresen módosítva."
        ]);
    }

    sendResponse(500, [
        "message" => "Nem sikerült módosítani az ingatlant."
    ]);
}

if ($method === "DELETE") {

    $propertyId = $data["propertyId"] ?? null;
    $ownerId = $data["ownerId"] ?? null;

    if (
        !validId($propertyId) ||
        !validId($ownerId)
    ) {
        sendResponse(400, [
            "message" => "Érvénytelen azonosító."
        ]);
    }

    if (getUserRole($connection, $ownerId) !== "tulajdonos") {
        sendResponse(403, [
            "message" => "Csak tulajdonos törölhet ingatlant."
        ]);
    }

    $statement = $connection->prepare(
        "DELETE FROM properties
         WHERE id = ? AND owner_id = ?"
    );

    $statement->bind_param(
        "ii",
        $propertyId,
        $ownerId
    );

    if ($statement->execute()) {

        if ($statement->affected_rows === 0) {
            sendResponse(404, [
                "message" => "Az ingatlan nem található."
            ]);
        }

        sendResponse(200, [
            "message" => "Az ingatlan sikeresen törölve."
        ]);
    }

    sendResponse(500, [
        "message" => "Nem sikerült törölni az ingatlant."
    ]);
}

header("Allow: GET, POST, PUT, DELETE");

sendResponse(405, [
    "message" => "Nem támogatott kérési metódus."
]);

?>
