
<?php

function getDatabaseConnection(): mysqli
{
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "property_db";

    $connection = new mysqli($host, $username, $password, $database);
    $connection->set_charset("utf8mb4");

    return $connection;
}