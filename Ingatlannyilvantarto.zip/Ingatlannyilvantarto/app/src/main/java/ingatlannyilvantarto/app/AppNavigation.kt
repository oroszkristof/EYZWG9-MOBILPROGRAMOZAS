package ingatlannyilvantarto.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ingatlannyilvantarto.app.network.DeleteProfileRequest
import ingatlannyilvantarto.app.network.UpdateProfileRequest
import ingatlannyilvantarto.app.network.DeletePropertyRequest
import ingatlannyilvantarto.app.network.LoginRequest
import ingatlannyilvantarto.app.network.PropertyRequest
import ingatlannyilvantarto.app.network.RegisterRequest
import ingatlannyilvantarto.app.network.RetrofitClient
import ingatlannyilvantarto.app.network.UpdatePropertyRequest
import ingatlannyilvantarto.app.ui.screen.DashboardScreen
import ingatlannyilvantarto.app.ui.screen.HomeScreen
import ingatlannyilvantarto.app.ui.screen.LoginScreen
import ingatlannyilvantarto.app.ui.screen.PropertiesScreen
import ingatlannyilvantarto.app.ui.screen.RegisterScreen
import kotlinx.coroutines.launch
import java.io.IOException

class AppNavigation {

    private enum class AppScreen {
        HOME,
        LOGIN,
        REGISTER,
        DASHBOARD,
        PROPERTIES,
        SETTLEMENTS,
        INVITATIONS,
        PROFILE
    }

    @Composable
    fun Show() {
        var currentScreen by rememberSaveable {
            mutableStateOf(AppScreen.HOME)
        }

        var isLoading by remember {
            mutableStateOf(false)
        }

        var registrationMessage by remember {
            mutableStateOf<String?>(null)
        }

        var loginMessage by remember {
            mutableStateOf<String?>(null)
        }

        var loggedInUserName by rememberSaveable {
            mutableStateOf("")
        }

        var loggedInUserId by rememberSaveable {
            mutableIntStateOf(0)
        }

        var loggedInUserEmail by rememberSaveable {
            mutableStateOf("")
        }

        var loggedInUserPhone by rememberSaveable {
            mutableStateOf("")
        }

        var profileMessage by remember { mutableStateOf<String?>(null) }

        var profileLoadedUserId by remember { mutableIntStateOf(0) }

        var propertyMessage by remember {
            mutableStateOf<String?>(null)
        }

        var propertySaveCompleted by remember {
            mutableIntStateOf(0)
        }

        val coroutineScope = rememberCoroutineScope()

        val apiService = remember {
            RetrofitClient().apiService
        }

        val backgroundColor = Color(0xFFFFE4A0)

        val isLoggedInScreen = currentScreen == AppScreen.DASHBOARD ||
                currentScreen == AppScreen.PROPERTIES ||
                currentScreen == AppScreen.SETTLEMENTS ||
                currentScreen == AppScreen.INVITATIONS ||
                currentScreen == AppScreen.PROFILE

        val logout: () -> Unit = {
            loggedInUserId = 0
            loggedInUserName = ""
            loggedInUserEmail = ""
            loggedInUserPhone = ""
            profileLoadedUserId = 0
            profileMessage = null
            loginMessage = null
            registrationMessage = null
            propertyMessage = null
            propertySaveCompleted = 0
            currentScreen = AppScreen.HOME
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentScreen) {

                    AppScreen.HOME -> HomeScreen().Show(
                        onNavigateToLogin = {
                            loginMessage = null
                            currentScreen = AppScreen.LOGIN
                        },
                        onNavigateToRegister = {
                            registrationMessage = null
                            currentScreen = AppScreen.REGISTER
                        }
                    )

                    AppScreen.LOGIN -> LoginScreen().Show(
                        onLogin = { email, password ->
                            if (!isLoading) {
                                coroutineScope.launch {
                                    isLoading = true
                                    loginMessage = null

                                    try {
                                        val response = apiService.login(
                                            LoginRequest(email, password)
                                        )

                                        if (response.isSuccessful) {
                                            val user = response.body()?.user

                                            if (user != null) {
                                                loggedInUserId = user.id
                                                loggedInUserName = user.name
                                                loggedInUserEmail = user.email
                                                loggedInUserPhone = user.phone.orEmpty()
                                                profileLoadedUserId = 0
                                                currentScreen = AppScreen.DASHBOARD
                                            } else {
                                                loginMessage = "Nem sikerült bejelentkezni."
                                            }
                                        } else {
                                            loginMessage = when (response.code()) {
                                                400 -> "Adja meg az e-mail-címet és a jelszót."
                                                401 -> "Hibás e-mail-cím vagy jelszó."
                                                else -> "A bejelentkezés sikertelen."
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        loginMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        loginMessage = "Hiba történt a bejelentkezés során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        onNavigateToRegister = {
                            registrationMessage = null
                            loginMessage = null
                            currentScreen = AppScreen.REGISTER
                        },
                        isLoading = isLoading,
                        errorMessage = loginMessage,
                        onNavigateToHome = {
                            loginMessage = null
                            currentScreen = AppScreen.HOME
                        }
                    )

                    AppScreen.REGISTER -> RegisterScreen().Show(
                        onRegister = { name, email, password, phone ->
                            if (!isLoading) {
                                coroutineScope.launch {
                                    isLoading = true
                                    registrationMessage = null

                                    try {
                                        val response = apiService.register(
                                            RegisterRequest(name, email, password, phone.ifBlank { null })
                                        )

                                        if (response.isSuccessful) {
                                            registrationMessage = null
                                            loginMessage = null
                                            currentScreen = AppScreen.LOGIN
                                        } else {
                                            registrationMessage = when (response.code()) {
                                                400 -> "Hibás regisztrációs adatok."
                                                409 -> "Ez az e-mail-cím már foglalt."
                                                else -> "A regisztráció sikertelen."
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        registrationMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        registrationMessage = "Váratlan hiba történt a regisztráció során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        onNavigateToLogin = {
                            registrationMessage = null
                            currentScreen = AppScreen.LOGIN
                        },
                        isLoading = isLoading,
                        errorMessage = registrationMessage,
                        onNavigateToHome = {
                            registrationMessage = null
                            currentScreen = AppScreen.HOME
                        }
                    )

                    AppScreen.DASHBOARD -> DashboardScreen().Show(
                        userName = loggedInUserName,
                        onNavigateToProperties = {
                            currentScreen = AppScreen.PROPERTIES
                        },
                        onNavigateToSettlements = {
                            currentScreen = AppScreen.SETTLEMENTS
                        },
                        onNavigateToInvitations = {
                            currentScreen = AppScreen.INVITATIONS
                        },
                        onLogout = logout
                    )

                    AppScreen.PROPERTIES -> PropertiesScreen().Show(
                        ownerId = loggedInUserId,
                        saveCompleted = propertySaveCompleted,
                        isSaving = isLoading,
                        onSaveProperty = { name, address, monthlyRent, paymentDueDay ->
                            if (!isLoading) {
                                coroutineScope.launch {
                                    isLoading = true
                                    propertyMessage = null

                                    try {
                                        if (loggedInUserId <= 0) {
                                            propertyMessage = "A felhasználó nincs bejelentkezve."
                                        } else {
                                            val response = apiService.addProperty(
                                                PropertyRequest(
                                                    ownerId = loggedInUserId,
                                                    name = name,
                                                    address = address,
                                                    monthlyRent = monthlyRent,
                                                    paymentDueDay = paymentDueDay
                                                )
                                            )

                                            if (response.isSuccessful) {
                                                propertySaveCompleted++
                                                propertyMessage = "Az ingatlan sikeresen hozzáadva."
                                            } else {
                                                propertyMessage = when (response.code()) {
                                                    400 -> "Ellenőrizze a megadott ingatlanadatokat."
                                                    else -> "Nem sikerült menteni az ingatlant."
                                                }
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        propertyMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        propertyMessage = "Hiba történt az ingatlan mentése során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        onUpdateProperty = { propertyId, name, address, monthlyRent, paymentDueDay ->
                            if (!isLoading) {
                                coroutineScope.launch {
                                    isLoading = true
                                    propertyMessage = null

                                    try {
                                        if (loggedInUserId <= 0) {
                                            propertyMessage = "A felhasználó nincs bejelentkezve."
                                        } else {
                                            val response = apiService.updateProperty(
                                                UpdatePropertyRequest(
                                                    propertyId = propertyId,
                                                    ownerId = loggedInUserId,
                                                    name = name,
                                                    address = address,
                                                    monthlyRent = monthlyRent,
                                                    paymentDueDay = paymentDueDay
                                                )
                                            )

                                            if (response.isSuccessful) {
                                                propertySaveCompleted++
                                                propertyMessage = "Az ingatlan sikeresen módosítva."
                                            } else {
                                                propertyMessage = when (response.code()) {
                                                    400 -> "Ellenőrizze a megadott ingatlanadatokat."
                                                    404 -> "A keresett ingatlan nem található."
                                                    else -> "Nem sikerült módosítani az ingatlant."
                                                }
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        propertyMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        propertyMessage = "Hiba történt az ingatlan módosítása során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        onDeleteProperty = { propertyId ->
                            if (!isLoading) {
                                coroutineScope.launch {
                                    isLoading = true
                                    propertyMessage = null

                                    try {
                                        if (loggedInUserId <= 0) {
                                            propertyMessage = "A felhasználó nincs bejelentkezve."
                                        } else {
                                            val response = apiService.deleteProperty(
                                                DeletePropertyRequest(
                                                    propertyId = propertyId,
                                                    ownerId = loggedInUserId
                                                )
                                            )

                                            if (response.isSuccessful) {
                                                propertySaveCompleted++
                                                propertyMessage = "Az ingatlan sikeresen törölve."
                                            } else {
                                                propertyMessage = when (response.code()) {
                                                    404 -> "A keresett ingatlan nem található."
                                                    else -> "Nem sikerült törölni az ingatlant."
                                                }
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        propertyMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        propertyMessage = "Hiba történt az ingatlan törlése során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        onBack = {
                            propertyMessage = null
                            currentScreen = AppScreen.DASHBOARD
                        }
                    )

                    AppScreen.SETTLEMENTS -> PlaceholderScreen(
                        title = "Elszámolások",
                        description = "Itt kezelheti majd az ingatlanokhoz tartozó elszámolásokat."
                    )

                    AppScreen.INVITATIONS -> PlaceholderScreen(
                        title = "Meghívók",
                        description = "Itt kezelheti majd a meghívásokat és a hozzáféréseket."
                    )

                    AppScreen.PROFILE -> ProfileScreen(
                        userName = loggedInUserName,
                        userEmail = loggedInUserEmail,
                        userPhone = loggedInUserPhone,
                        isLoading = isLoading,
                        onUpdateProfile = { name, email, phone, password ->
                            if (!isLoading && loggedInUserId > 0) {
                                coroutineScope.launch {
                                    isLoading = true
                                    try {
                                        val response = apiService.updateProfile(
                                            UpdateProfileRequest(
                                                userId = loggedInUserId,
                                                name = name.trim(),
                                                email = email.trim(),
                                                phone = phone.trim().ifBlank { null },
                                                password = password
                                            )
                                        )
                                        if (response.isSuccessful && response.body()?.user != null) {
                                            val user = response.body()!!.user!!
                                            loggedInUserName = user.name
                                            loggedInUserEmail = user.email
                                            loggedInUserPhone = user.phone.orEmpty()
                                            profileMessage = "A profiladatok sikeresen módosítva."
                                        } else {
                                            profileMessage = when (response.code()) {
                                                400 -> "Ellenőrizze a megadott adatokat."
                                                404 -> "A felhasználó nem található."
                                                409 -> "Ez az e-mail-cím már foglalt."
                                                else -> "Nem sikerült módosítani a profiladatokat."
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        profileMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        profileMessage = "Hiba történt a profil módosítása során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        },
                        onDeleteProfile = {
                            if (!isLoading && loggedInUserId > 0) {
                                coroutineScope.launch {
                                    isLoading = true
                                    try {
                                        val response = apiService.deleteProfile(
                                            DeleteProfileRequest(loggedInUserId)
                                        )
                                        if (response.isSuccessful) {
                                            logout()
                                        } else {
                                            profileMessage = when (response.code()) {
                                                404 -> "A felhasználó nem található."
                                                else -> "Nem sikerült törölni a fiókot."
                                            }
                                        }
                                    } catch (exception: IOException) {
                                        profileMessage = "Nem sikerült kapcsolódni a szerverhez."
                                    } catch (exception: Exception) {
                                        profileMessage = "Hiba történt a fiók törlése során."
                                    } finally {
                                        isLoading = false
                                    }
                                }
                            }
                        }
                    )
                }
            }

            if (isLoggedInScreen) {
                BottomNavigation(
                    selectedScreen = currentScreen,
                    onNavigate = { screen ->
                        propertyMessage = null
                        currentScreen = screen
                    }
                )
            }
        }

        LaunchedEffect(currentScreen, loggedInUserId) {
            if (currentScreen == AppScreen.PROFILE && loggedInUserId > 0 && profileLoadedUserId != loggedInUserId) {
                try {
                    val response = apiService.getProfile(loggedInUserId)
                    if (response.isSuccessful) {
                        val user = response.body()?.user
                        if (user != null) {
                            loggedInUserName = user.name
                            loggedInUserEmail = user.email
                            loggedInUserPhone = user.phone.orEmpty()
                            profileLoadedUserId = loggedInUserId
                        } else {
                            profileMessage = "Nem sikerült betölteni a profiladatokat."
                        }
                    } else {
                        profileMessage = "Nem sikerült betölteni a profiladatokat."
                    }
                } catch (exception: Exception) {
                    profileMessage = "Nem sikerült kapcsolódni a szerverhez."
                }
            }
        }

        if (profileMessage != null) {
            AlertDialog(
                onDismissRequest = { profileMessage = null },
                title = { Text("Értesítés") },
                text = { Text(profileMessage ?: "") },
                confirmButton = {
                    TextButton(onClick = { profileMessage = null }) {
                        Text("Rendben")
                    }
                }
            )
        }

        if (propertyMessage != null) {
            AlertDialog(
                onDismissRequest = {
                    propertyMessage = null
                },
                title = {
                    Text("Értesítés")
                },
                text = {
                    Text(propertyMessage ?: "")
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            propertyMessage = null
                        }
                    ) {
                        Text("Rendben")
                    }
                }
            )
        }
    }

    @Composable
    private fun BottomNavigation(
        selectedScreen: AppScreen,
        onNavigate: (AppScreen) -> Unit
    ) {
        val darkColor = Color(0xFF111827)
        val yellowColor = Color(0xFFFFD633)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp)
                .background(
                    color = darkColor,
                    shape = RoundedCornerShape(28.dp)
                )
                .padding(horizontal = 6.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavigationItem(
                title = "Főoldal",
                symbol = "⌂",
                selected = selectedScreen == AppScreen.DASHBOARD,
                selectedColor = yellowColor,
                onClick = {
                    onNavigate(AppScreen.DASHBOARD)
                },
                modifier = Modifier.weight(1f)
            )

            NavigationItem(
                title = "Ingatlanok",
                symbol = "▤",
                selected = selectedScreen == AppScreen.PROPERTIES,
                selectedColor = yellowColor,
                onClick = {
                    onNavigate(AppScreen.PROPERTIES)
                },
                modifier = Modifier.weight(1f)
            )

            NavigationItem(
                title = "Elszámolás",
                symbol = "€",
                selected = selectedScreen == AppScreen.SETTLEMENTS,
                selectedColor = yellowColor,
                onClick = {
                    onNavigate(AppScreen.SETTLEMENTS)
                },
                modifier = Modifier.weight(1f)
            )

            NavigationItem(
                title = "Meghívók",
                symbol = "✉",
                selected = selectedScreen == AppScreen.INVITATIONS,
                selectedColor = yellowColor,
                onClick = {
                    onNavigate(AppScreen.INVITATIONS)
                },
                modifier = Modifier.weight(1f)
            )

            NavigationItem(
                title = "Profil",
                symbol = "●",
                selected = selectedScreen == AppScreen.PROFILE,
                selectedColor = yellowColor,
                onClick = {
                    onNavigate(AppScreen.PROFILE)
                },
                modifier = Modifier.weight(1f)
            )
        }
    }

    @Composable
    private fun NavigationItem(
        title: String,
        symbol: String,
        selected: Boolean,
        selectedColor: Color,
        onClick: () -> Unit,
        modifier: Modifier = Modifier
    ) {
        val itemColor = if (selected) {
            selectedColor
        } else {
            Color.White
        }

        Column(
            modifier = modifier
                .clickable(onClick = onClick)
                .padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = symbol,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                color = itemColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = title,
                fontSize = 9.sp,
                fontWeight = if (selected) {
                    FontWeight.Bold
                } else {
                    FontWeight.Normal
                },
                color = itemColor,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }

    @Composable
    private fun PlaceholderScreen(
        title: String,
        description: String
    ) {
        val darkColor = Color(0xFF111827)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFFFE4A0))
                .padding(24.dp)
        ) {
            Text(
                text = "INGATLANNYILVÁNTARTÓ",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = title,
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFFFFAED)
                )
            ) {
                Text(
                    text = description,
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                    color = darkColor,
                    modifier = Modifier.padding(24.dp)
                )
            }
        }
    }

    @Composable
    private fun ProfileScreen(
        userName: String,
        userEmail: String,
        userPhone: String,
        isLoading: Boolean,
        onUpdateProfile: (String, String, String, String) -> Unit,
        onDeleteProfile: () -> Unit
    ) {
        val darkColor = Color(0xFF111827)
        val backgroundColor = Color(0xFFFFE4A0)
        val cardColor = Color(0xFFFFFAED)
        val yellowColor = Color(0xFFFFD633)
        val redColor = Color(0xFFB42318)

        var showEditDialog by remember { mutableStateOf(false) }
        var showDeleteDialog by remember { mutableStateOf(false) }
        var editName by remember(userName) { mutableStateOf(userName) }
        var editEmail by remember(userEmail) { mutableStateOf(userEmail) }
        var editPhone by remember(userPhone) { mutableStateOf(userPhone) }
        var editPassword by remember { mutableStateOf("") }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = "INGATLANNYILVÁNTARTÓ",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Profil",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Személyes adatok és fiókbeállítások",
                fontSize = 15.sp,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(28.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = cardColor)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp)
                ) {
                    Text(
                        text = "Személyes adatok",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = darkColor
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    ProfileField("Teljes név", userName.ifBlank { "Nincs megadva" })
                    Spacer(modifier = Modifier.height(20.dp))
                    ProfileField("E-mail-cím", userEmail.ifBlank { "Nem érhető el" })
                    Spacer(modifier = Modifier.height(20.dp))
                    ProfileField("Telefonszám", userPhone.ifBlank { "Nincs megadva" })
                    Spacer(modifier = Modifier.height(20.dp))
                    ProfileField("Jelszó", "••••••••")

                    Spacer(modifier = Modifier.height(26.dp))

                    Button(
                        onClick = {
                            editName = userName
                            editEmail = userEmail
                            editPhone = userPhone
                            editPassword = ""
                            showEditDialog = true
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = yellowColor,
                            contentColor = darkColor
                        )
                    ) {
                        Text(
                            text = "Adatok módosítása",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { showDeleteDialog = true },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = redColor,
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "Fiók törlése",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        if (showEditDialog) {
            AlertDialog(
                onDismissRequest = { showEditDialog = false },
                title = {
                    Text("Adatok módosítása", color = darkColor)
                },
                text = {
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .imePadding(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Teljes név") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = editEmail,
                            onValueChange = { editEmail = it },
                            label = { Text("E-mail-cím") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = editPhone,
                            onValueChange = { editPhone = it },
                            label = { Text("Telefonszám") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = editPassword,
                            onValueChange = { editPassword = it },
                            label = { Text("Új jelszó (opcionális)") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = !isLoading,
                        onClick = {
                            showEditDialog = false
                            onUpdateProfile(editName, editEmail, editPhone, editPassword)
                        }
                    ) {
                        Text("Mentés", color = darkColor)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditDialog = false }) {
                        Text("Mégse", color = darkColor)
                    }
                },
                containerColor = backgroundColor
            )
        }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text("Fiók törlése", color = darkColor) },
                text = {
                    Text(
                        "Biztosan véglegesen törölni szeretné a fiókját?",
                        color = darkColor
                    )
                },
                confirmButton = {
                    TextButton(
                        enabled = !isLoading,
                        onClick = {
                            showDeleteDialog = false
                            onDeleteProfile()
                        }
                    ) {
                        Text("Törlés", color = redColor)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) {
                        Text("Mégse", color = darkColor)
                    }
                },
                containerColor = backgroundColor
            )
        }

    }

    @Composable
    private fun ProfileField(label: String, value: String) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = Color(0xFF6B7280)
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = value,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF111827)
        )
    }
}
