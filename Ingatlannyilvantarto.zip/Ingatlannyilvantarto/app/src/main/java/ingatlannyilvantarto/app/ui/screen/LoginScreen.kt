
package ingatlannyilvantarto.app.ui.screen

import android.util.Patterns
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class LoginScreen {

    @Composable
    fun Show(
        onLogin: (String, String) -> Unit,
        onNavigateToRegister: () -> Unit,
        isLoading: Boolean = false,
        errorMessage: String? = null,
        onNavigateToHome: () -> Unit = {}
    ) {
        var email by rememberSaveable {
            mutableStateOf("")
        }

        var password by rememberSaveable {
            mutableStateOf("")
        }

        var validationMessage by rememberSaveable {
            mutableStateOf<String?>(null)
        }

        val backgroundColor = Color(0xFFFFE4A0)
        val darkColor = Color(0xFF111827)
        val fieldColor = Color(0xFFFFFAED)

        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = fieldColor,
            unfocusedContainerColor = fieldColor,
            disabledContainerColor = fieldColor,
            focusedBorderColor = darkColor,
            unfocusedBorderColor = Color.Transparent,
            focusedTextColor = darkColor,
            unfocusedTextColor = darkColor,
            focusedLabelColor = darkColor,
            unfocusedLabelColor = Color.DarkGray,
            cursorColor = darkColor
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {

            Text(
                text = "←",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor,
                modifier = Modifier
                    .clickable(
                        enabled = !isLoading,
                        onClick = onNavigateToHome
                    )
                    .padding(bottom = 20.dp)
            )

            Text(
                text = "INGATLANNYILVÁNTARTÓ",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Üdvözöljük\nújra!",
                fontSize = 40.sp,
                lineHeight = 44.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Jelentkezzen be, és kezelje ingatlanjait egyszerűen, egyetlen helyen.",
                fontSize = 16.sp,
                lineHeight = 23.sp,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    validationMessage = null
                },
                label = {
                    Text("E-mail-cím")
                },
                singleLine = true,
                enabled = !isLoading,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    validationMessage = null
                },
                label = {
                    Text("Jelszó")
                },
                singleLine = true,
                enabled = !isLoading,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            val displayedError = validationMessage ?: errorMessage

            if (displayedError != null) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = displayedError,
                    color = Color(0xFFB42318),
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    val normalizedEmail = email.trim()

                    validationMessage = validateLoginInput(
                        normalizedEmail,
                        password
                    )

                    if (validationMessage == null) {
                        onLogin(normalizedEmail, password)
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = darkColor,
                    contentColor = Color.White
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "Bejelentkezés",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onNavigateToRegister,
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    width = 1.5.dp,
                    color = darkColor
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = darkColor
                )
            ) {
                Text(
                    text = "Regisztráció",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }

    private fun validateLoginInput(
        email: String,
        password: String
    ): String? {

        if (email.isBlank()) {
            return "Az e-mail-cím megadása kötelező."
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return "Érvénytelen e-mail-cím."
        }

        if (password.isBlank()) {
            return "A jelszó megadása kötelező."
        }

        return null
    }
}
