
package ingatlannyilvantarto.app.network

data class UpdateProfileRequest(
    val userId: Int,
    val name: String,
    val email: String,
    val phone: String?,
    val password: String = ""
)

data class DeleteProfileRequest(
    val userId: Int
)
