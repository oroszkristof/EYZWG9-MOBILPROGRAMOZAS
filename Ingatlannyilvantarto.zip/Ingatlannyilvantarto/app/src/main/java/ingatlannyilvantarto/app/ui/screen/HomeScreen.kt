
package ingatlannyilvantarto.app.ui.screen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ingatlannyilvantarto.app.R

class HomeScreen {

    @Composable
    fun Show(
        onNavigateToLogin: () -> Unit,
        onNavigateToRegister: () -> Unit
    ) {
        val backgroundColor = Color(0xFFFFE4A0)
        val darkColor = Color(0xFF111827)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                .padding(
                    horizontal = 24.dp,
                    vertical = 28.dp
                ),
            horizontalAlignment = Alignment.Start
        ) {

            Text(
                text = "INGATLANNYILVÁNTARTÓ",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(
                modifier = Modifier.height(24.dp)
            )

            Text(
                text = "Ingatlanjai,\negy helyen.",
                fontSize = 40.sp,
                lineHeight = 44.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            Text(
                text = "Kezelje ingatlanjait, költségeit és elszámolásait egyszerűen, átláthatóan.",
                fontSize = 16.sp,
                lineHeight = 23.sp,
                color = darkColor
            )

            Spacer(
                modifier = Modifier.height(28.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .border(
                        width = 1.dp,
                        color = Color(0xFFE8D9A9),
                        shape = RoundedCornerShape(28.dp)
                    )
            ) {
                Image(
                    painter = painterResource(
                        id = R.drawable.apartment_building
                    ),
                    contentDescription = "Modern lakóépület",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(
                modifier = Modifier.height(28.dp)
            )

            Button(
                onClick = onNavigateToRegister,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = darkColor,
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "Regisztráció",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            OutlinedButton(
                onClick = onNavigateToLogin,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    width = 1.5.dp,
                    color = darkColor
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = darkColor
                )
            ) {
                Text(
                    text = "Bejelentkezés",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
