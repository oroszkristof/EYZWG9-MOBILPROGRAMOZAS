
package ingatlannyilvantarto.app.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.HTTP
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query

interface ApiService {

    @POST("register.php")
    suspend fun register(
        @Body request: RegisterRequest
    ): Response<AuthResponse>

    @POST("login.php")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<AuthResponse>

    @POST("properties.php")
    suspend fun addProperty(
        @Body request: PropertyRequest
    ): Response<PropertyActionResponse>

    @GET("properties.php")
    suspend fun getProperties(
        @Query("ownerId") ownerId: Int
    ): Response<PropertiesResponse>

    @GET("properties.php")
    suspend fun getProperty(
        @Query("ownerId") ownerId: Int,
        @Query("propertyId") propertyId: Int
    ): Response<PropertyResponse>

    @PUT("properties.php")
    suspend fun updateProperty(
        @Body request: UpdatePropertyRequest
    ): Response<PropertyActionResponse>

    @HTTP(method = "DELETE", path = "properties.php", hasBody = true)
    suspend fun deleteProperty(
        @Body request: DeletePropertyRequest
    ): Response<PropertyActionResponse>

    @GET("profile.php")
    suspend fun getProfile(
        @Query("userId") userId: Int
    ): Response<AuthResponse>

    @PUT("profile.php")
    suspend fun updateProfile(
        @Body request: UpdateProfileRequest
    ): Response<AuthResponse>

    @HTTP(method = "DELETE", path = "profile.php", hasBody = true)
    suspend fun deleteProfile(
        @Body request: DeleteProfileRequest
    ): Response<AuthResponse>
}
