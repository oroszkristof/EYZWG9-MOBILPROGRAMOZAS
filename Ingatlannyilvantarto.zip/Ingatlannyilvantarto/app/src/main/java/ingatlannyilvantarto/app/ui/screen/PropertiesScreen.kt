
package ingatlannyilvantarto.app.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ingatlannyilvantarto.app.network.Property
import ingatlannyilvantarto.app.network.RetrofitClient
import java.io.IOException

class PropertiesScreen {

    @Composable
    fun Show(
        ownerId: Int,
        saveCompleted: Int,
        isSaving: Boolean,
        onSaveProperty: (String, String, Double, Int) -> Unit,
        onUpdateProperty: (Int, String, String, Double, Int) -> Unit,
        onDeleteProperty: (Int) -> Unit,
        onBack: () -> Unit
    ) {
        val backgroundColor = Color(0xFFFFE4A0)
        val darkColor = Color(0xFF111827)
        val cardColor = Color(0xFFFFFAED)
        val yellowColor = Color(0xFFFFD633)

        var showForm by rememberSaveable {
            mutableStateOf(false)
        }

        var editingPropertyId by rememberSaveable {
            mutableStateOf<Int?>(null)
        }

        var deletingPropertyId by rememberSaveable {
            mutableStateOf<Int?>(null)
        }

        var name by rememberSaveable {
            mutableStateOf("")
        }

        var address by rememberSaveable {
            mutableStateOf("")
        }

        var monthlyRent by rememberSaveable {
            mutableStateOf("")
        }

        var paymentDueDay by rememberSaveable {
            mutableStateOf("")
        }

        var errorMessage by rememberSaveable {
            mutableStateOf("")
        }

        var properties by remember {
            mutableStateOf<List<Property>>(emptyList())
        }

        var isLoading by remember {
            mutableStateOf(false)
        }

        var loadError by remember {
            mutableStateOf("")
        }

        val apiService = remember {
            RetrofitClient().apiService
        }

        LaunchedEffect(ownerId, saveCompleted) {
            if (ownerId <= 0) {
                properties = emptyList()
                loadError = "A felhasználó nincs bejelentkezve."
                return@LaunchedEffect
            }

            isLoading = true
            loadError = ""

            try {
                val response = apiService.getProperties(ownerId)

                if (response.isSuccessful) {
                    properties = response.body()?.properties ?: emptyList()
                } else {
                    loadError = "Nem sikerült lekérni az ingatlanokat."
                }
            } catch (exception: IOException) {
                loadError = "Nem sikerült kapcsolódni a szerverhez."
            } catch (exception: Exception) {
                loadError = "Hiba történt az ingatlanok lekérése során."
            } finally {
                isLoading = false
            }
        }

        LaunchedEffect(saveCompleted) {
            if (saveCompleted > 0) {
                showForm = false
                editingPropertyId = null
                deletingPropertyId = null
                name = ""
                address = ""
                monthlyRent = ""
                paymentDueDay = ""
                errorMessage = ""
            }
        }

        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = cardColor,
            unfocusedContainerColor = cardColor,
            disabledContainerColor = cardColor,
            focusedBorderColor = darkColor,
            unfocusedBorderColor = Color.Transparent,
            focusedTextColor = darkColor,
            unfocusedTextColor = darkColor,
            focusedLabelColor = darkColor,
            unfocusedLabelColor = Color.DarkGray,
            cursorColor = darkColor
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Text(
                text = "INGATLANNYILVÁNTARTÓ",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Ingatlanok",
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = darkColor
                    )

                    Text(
                        text = "Kezelje ingatlanjait egy helyen.",
                        fontSize = 14.sp,
                        color = darkColor
                    )
                }

                Button(
                    onClick = {
                        editingPropertyId = null
                        name = ""
                        address = ""
                        monthlyRent = ""
                        paymentDueDay = ""
                        errorMessage = ""
                        showForm = true
                    },
                    enabled = !isSaving,
                    modifier = Modifier.size(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = darkColor,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = "+",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = darkColor)
                }
            } else if (loadError.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = cardColor
                    )
                ) {
                    Text(
                        text = loadError,
                        color = Color(0xFFB42318),
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else if (properties.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = cardColor
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "⌂",
                            fontSize = 48.sp,
                            color = darkColor
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Még nincs rögzített ingatlana.",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = darkColor,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Új ingatlan hozzáadásához nyomja meg a + gombot.",
                            fontSize = 14.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                properties.forEach { property ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = cardColor
                        ),
                        elevation = CardDefaults.cardElevation(
                            defaultElevation = 2.dp
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Text(
                                text = property.name,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = darkColor
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "⌖  ${property.address}",
                                fontSize = 14.sp,
                                color = Color(0xFF4B5563)
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "Havi bérleti díj",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "${property.monthlyRent.toLong()} Ft",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = darkColor
                                    )
                                }

                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "Fizetési határnap",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "Minden hónap ${property.paymentDueDay}.",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = darkColor
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(22.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        editingPropertyId = property.id
                                        name = property.name
                                        address = property.address
                                        monthlyRent = property.monthlyRent.toString()
                                        paymentDueDay = property.paymentDueDay.toString()
                                        errorMessage = ""
                                        showForm = true
                                    },
                                    enabled = !isSaving,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = yellowColor,
                                        contentColor = darkColor
                                    )
                                ) {
                                    Text(
                                        text = "Módosítás",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                OutlinedButton(
                                    onClick = {
                                        deletingPropertyId = property.id
                                    },
                                    enabled = !isSaving,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "Törlés",
                                        fontSize = 13.sp,
                                        color = darkColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showForm) {
            AlertDialog(
                onDismissRequest = {
                    if (!isSaving) {
                        showForm = false
                        editingPropertyId = null
                        errorMessage = ""
                    }
                },
                title = {
                    Text(
                        text = if (editingPropertyId == null) {
                            "Új ingatlan"
                        } else {
                            "Ingatlan módosítása"
                        },
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold,
                        color = darkColor
                    )
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "Adja meg az ingatlan adatait.",
                            fontSize = 14.sp,
                            color = darkColor
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = name,
                            onValueChange = {
                                name = it
                                errorMessage = ""
                            },
                            label = {
                                Text("Ingatlan neve")
                            },
                            enabled = !isSaving,
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = address,
                            onValueChange = {
                                address = it
                                errorMessage = ""
                            },
                            label = {
                                Text("Ingatlan címe")
                            },
                            enabled = !isSaving,
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = monthlyRent,
                            onValueChange = {
                                monthlyRent = it
                                errorMessage = ""
                            },
                            label = {
                                Text("Havi bérleti díj (Ft)")
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Decimal
                            ),
                            enabled = !isSaving,
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = paymentDueDay,
                            onValueChange = {
                                paymentDueDay = it
                                errorMessage = ""
                            },
                            label = {
                                Text("Fizetési határnap (1–28)")
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number
                            ),
                            enabled = !isSaving,
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (errorMessage.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = errorMessage,
                                color = Color(0xFFB42318),
                                fontSize = 13.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val rent = monthlyRent
                                .replace(",", ".")
                                .toDoubleOrNull()

                            val dueDay = paymentDueDay.toIntOrNull()

                            when {
                                name.isBlank() ||
                                        address.isBlank() ||
                                        monthlyRent.isBlank() ||
                                        paymentDueDay.isBlank() -> {
                                    errorMessage = "Minden mező kitöltése kötelező."
                                }

                                name.trim().length > 100 -> {
                                    errorMessage = "Az ingatlan neve legfeljebb 100 karakter lehet."
                                }

                                address.trim().length > 255 -> {
                                    errorMessage = "Az ingatlan címe legfeljebb 255 karakter lehet."
                                }

                                rent == null ||
                                        !rent.isFinite() ||
                                        rent < 0 ||
                                        rent > 99999999.99 -> {
                                    errorMessage = "Adjon meg érvényes havi bérleti díjat."
                                }

                                dueDay == null || dueDay !in 1..28 -> {
                                    errorMessage = "A fizetési határnap 1 és 28 közötti szám lehet."
                                }

                                else -> {
                                    errorMessage = ""

                                    val propertyId = editingPropertyId

                                    if (propertyId == null) {
                                        onSaveProperty(
                                            name.trim(),
                                            address.trim(),
                                            rent,
                                            dueDay
                                        )
                                    } else {
                                        onUpdateProperty(
                                            propertyId,
                                            name.trim(),
                                            address.trim(),
                                            rent,
                                            dueDay
                                        )
                                    }
                                }
                            }
                        },
                        enabled = !isSaving,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = darkColor,
                            contentColor = Color.White
                        )
                    ) {
                        Text(
                            text = if (isSaving) {
                                "Mentés..."
                            } else {
                                "Mentés"
                            }
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showForm = false
                            editingPropertyId = null
                            errorMessage = ""
                        },
                        enabled = !isSaving
                    ) {
                        Text(
                            text = "Mégse",
                            color = darkColor
                        )
                    }
                },
                shape = RoundedCornerShape(24.dp),
                containerColor = backgroundColor
            )
        }

        if (deletingPropertyId != null) {
            AlertDialog(
                onDismissRequest = {
                    if (!isSaving) {
                        deletingPropertyId = null
                    }
                },
                title = {
                    Text(
                        text = "Ingatlan törlése",
                        fontWeight = FontWeight.Bold,
                        color = darkColor
                    )
                },
                text = {
                    Text(
                        text = "Biztosan törölni szeretné ezt az ingatlant?",
                        color = darkColor
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val propertyId = deletingPropertyId

                            if (propertyId != null) {
                                onDeleteProperty(propertyId)
                                deletingPropertyId = null
                            }
                        },
                        enabled = !isSaving
                    ) {
                        Text(
                            text = "Törlés",
                            color = Color(0xFFB42318)
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            deletingPropertyId = null
                        },
                        enabled = !isSaving
                    ) {
                        Text(
                            text = "Mégse",
                            color = darkColor
                        )
                    }
                },
                shape = RoundedCornerShape(24.dp),
                containerColor = backgroundColor
            )
        }
    }
}
