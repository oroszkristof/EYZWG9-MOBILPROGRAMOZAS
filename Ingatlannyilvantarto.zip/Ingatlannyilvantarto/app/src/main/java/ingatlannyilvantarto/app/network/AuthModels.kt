
package ingatlannyilvantarto.app.network

data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String,
    val phone: String? = null
)

data class LoginRequest(
    val email: String,
    val password: String
)

data class User(
    val id: Int,
    val name: String,
    val email: String,
    val phone: String? = null
)

data class AuthResponse(
    val message: String,
    val userId: Int? = null,
    val user: User? = null
)
