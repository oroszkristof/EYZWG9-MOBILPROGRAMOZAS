package ingatlannyilvantarto.app.ui.screen

import android.util.Patterns
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class RegisterScreen {

    @Composable
    fun Show(
        onRegister: (String, String, String, String) -> Unit,
        onNavigateToLogin: () -> Unit,
        isLoading: Boolean = false,
        errorMessage: String? = null,
        onNavigateToHome: () -> Unit = {}
    ) {
        var name by rememberSaveable {
            mutableStateOf("")
        }

        var email by rememberSaveable {
            mutableStateOf("")
        }

        var phone by rememberSaveable {
            mutableStateOf("")
        }

        var password by rememberSaveable {
            mutableStateOf("")
        }

        var confirmPassword by rememberSaveable {
            mutableStateOf("")
        }

        var validationMessage by rememberSaveable {
            mutableStateOf<String?>(null)
        }

        val backgroundColor = Color(0xFFFFE4A0)
        val darkColor = Color(0xFF111827)
        val fieldColor = Color(0xFFFFFAED)

        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = fieldColor,
            unfocusedContainerColor = fieldColor,
            disabledContainerColor = fieldColor,
            focusedBorderColor = darkColor,
            unfocusedBorderColor = Color.Transparent,
            focusedTextColor = darkColor,
            unfocusedTextColor = darkColor,
            focusedLabelColor = darkColor,
            unfocusedLabelColor = Color.DarkGray,
            cursorColor = darkColor
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "←",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor,
                modifier = Modifier
                    .clickable(
                        enabled = !isLoading,
                        onClick = onNavigateToHome
                    )
                    .padding(bottom = 20.dp)
            )

            Text(
                text = "INGATLANNYILVÁNTARTÓ",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Hozza létre\nfiókját.",
                fontSize = 40.sp,
                lineHeight = 44.sp,
                fontWeight = FontWeight.Bold,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Regisztráljon, és kezelje ingatlanjait egyszerűen, egyetlen helyen.",
                fontSize = 16.sp,
                lineHeight = 23.sp,
                color = darkColor
            )

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    validationMessage = null
                },
                label = {
                    Text("Teljes név")
                },
                singleLine = true,
                enabled = !isLoading,
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    validationMessage = null
                },
                label = {
                    Text("E-mail-cím")
                },
                singleLine = true,
                enabled = !isLoading,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = {
                    phone = it
                    validationMessage = null
                },
                label = {
                    Text("Telefonszám (nem kötelező)")
                },
                singleLine = true,
                enabled = !isLoading,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone
                ),
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    validationMessage = null
                },
                label = {
                    Text("Jelszó")
                },
                singleLine = true,
                enabled = !isLoading,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = {
                    confirmPassword = it
                    validationMessage = null
                },
                label = {
                    Text("Jelszó megerősítése")
                },
                singleLine = true,
                enabled = !isLoading,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                shape = RoundedCornerShape(16.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )

            val displayedError = validationMessage ?: errorMessage

            if (displayedError != null) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = displayedError,
                    color = Color(0xFFB42318),
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    val normalizedName = name.trim()
                    val normalizedEmail = email.trim()

                    validationMessage = validateRegisterInput(
                        normalizedName,
                        normalizedEmail,
                        phone.trim(),
                        password,
                        confirmPassword
                    )

                    if (validationMessage == null) {
                        onRegister(
                            normalizedName,
                            normalizedEmail,
                            password,
                            phone.trim()
                        )
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = darkColor,
                    contentColor = Color.White
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "Regisztráció",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    private fun validateRegisterInput(
        name: String,
        email: String,
        phone: String,
        password: String,
        confirmPassword: String
    ): String? {

        if (name.isBlank()) {
            return "A név megadása kötelező."
        }

        if (email.isBlank()) {
            return "Az e-mail-cím megadása kötelező."
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return "Érvénytelen e-mail-cím."
        }

        if (phone.length > 30) {
            return "A telefonszám legfeljebb 30 karakter lehet."
        }

        if (password.isBlank()) {
            return "A jelszó megadása kötelező."
        }

        if (password.length < 8) {
            return "A jelszónak legalább 8 karakterből kell állnia."
        }

        if (confirmPassword.isBlank()) {
            return "A jelszó megerősítése kötelező."
        }

        if (password != confirmPassword) {
            return "A megadott jelszavak nem egyeznek."
        }

        return null
    }
}
