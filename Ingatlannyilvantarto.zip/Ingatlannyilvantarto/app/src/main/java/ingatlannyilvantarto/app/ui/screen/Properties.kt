
package ingatlannyilvantarto.app.network

data class Property(
    val id: Int,
    val ownerId: Int,
    val name: String,
    val address: String,
    val monthlyRent: Double,
    val paymentDueDay: Int
)

data class PropertyRequest(
    val ownerId: Int,
    val name: String,
    val address: String,
    val monthlyRent: Double,
    val paymentDueDay: Int
)

data class UpdatePropertyRequest(
    val propertyId: Int,
    val ownerId: Int,
    val name: String,
    val address: String,
    val monthlyRent: Double,
    val paymentDueDay: Int
)

data class DeletePropertyRequest(
    val propertyId: Int,
    val ownerId: Int
)

data class PropertiesResponse(
    val properties: List<Property>
)

data class PropertyResponse(
    val property: Property
)

data class PropertyActionResponse(
    val message: String,
    val propertyId: Int? = null
)
